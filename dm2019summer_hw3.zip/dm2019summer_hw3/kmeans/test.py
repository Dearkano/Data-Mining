import numpy as np
import math
a = np.array([1,2,3,5,6,7])
b= np.array([1,2,3,5,6,7])
print((a==b).all())