import numpy as np

a=[1,2]
b=[3,4]
c=[2,4]
d=[1,2]
print(np.vstack((a,b,c,d)))