import numpy as np

a = [[1,2,3,1,2,3],[4,5,6,4,5,6],[1,1,1,1,1,1]]
b = np.cov(a)
print(np.cos(0.7))