load('TDT2_data', 'fea', 'gnd');

% YOUR CODE HERE